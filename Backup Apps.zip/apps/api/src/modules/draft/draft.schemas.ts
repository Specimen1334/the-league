// apps/api/src/modules/draft/draft.schemas.ts

/**
 * Draft lifecycle status for a season.
 * Matches the design doc: Not started / Lobby / In progress / Paused / Completed.
 */
export type DraftStatus =
  | "NotStarted"
  | "Lobby"
  | "InProgress"
  | "Paused"
  | "Completed";

/**
 * Draft format.
 * For now we primarily implement Snake & Linear. Custom can be
 * supported later using configJson in the repo.
 */
export type DraftType = "Snake" | "Linear" | "Custom";

/**
 * A participant in the draft lobby.
 */
export type DraftLobbyParticipant = {
  teamId: number;
  teamName: string;
  managerUserId: number;
  managerDisplayName: string | null;
  position: number;
  isReady: boolean;
  isYou: boolean;
};

/**
 * Lobby overview:
 * Used by GET /seasons/:seasonId/draft/lobby
 */
export type DraftLobbyResponse = {
  seasonId: number;
  status: DraftStatus;
  type: DraftType;
  startsAt: string | null;
  pickTimerSeconds: number | null;
  roundCount: number | null;

  participants: DraftLobbyParticipant[];
};

/**
 * Live draft pick state.
 * Used by GET /seasons/:seasonId/draft/state
 */
export type DraftStateResponse = {
  seasonId: number;
  status: DraftStatus;
  type: DraftType;

  currentRound: number;         // 1-based
  currentPickInRound: number;   // 1-based
  overallPickNumber: number;    // 1-based (next pick)
  totalTeams: number;

  teamOnTheClock: {
    teamId: number;
    teamName: string;
  } | null;

  timer: {
    pickTimerSeconds: number | null;
  };

  picks: {
    id: number;
    round: number;
    pickInRound: number;
    overallPickNumber: number;
    teamId: number;
    teamName: string | null;
    pokemonId: number;
  }[];
};

/**
 * Query params for GET /seasons/:seasonId/draft/pool
 */
export type DraftPoolQuery = {
  search?: string;
  type?: string;
  role?: string;
  onlyAvailable?: boolean;
  page?: number;
  limit?: number;
};

/**
 * Pool entry for draft.
 */
export type DraftPoolItem = {
  pokemonId: number;
  name: string;
  types: string[];
  roles: string[];
  baseCost: number | null;
  isPicked: boolean;
  pickedByTeamId: number | null;
};

/**
 * Response for GET /seasons/:seasonId/draft/pool
 */
export type DraftPoolResponse = {
  seasonId: number;
  items: DraftPoolItem[];
  page: number;
  limit: number;
  total: number;
};

/**
 * Body for POST /seasons/:seasonId/draft/pick
 */
export type DraftPickBody = {
  pokemonId: number;
};

/**
 * Per-team draft result.
 * Used by GET /seasons/:seasonId/draft/results
 * and GET /seasons/:seasonId/draft/results/:teamId
 */
export type DraftResultsTeam = {
  teamId: number;
  teamName: string;
  position: number;
  picks: {
    round: number;
    pickInRound: number;
    overallPickNumber: number;
    pokemonId: number;
  }[];
};

export type DraftResultsResponse = {
  seasonId: number;
  type: DraftType;
  status: DraftStatus;
  teams: DraftResultsTeam[];
};
