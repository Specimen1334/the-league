// apps/api/src/modules/matches/matches.service.ts
import type { AppUser } from "../../shared/types";
import { matchesRepo } from "./matches.repo";
import { matchesRecordingService } from "./matches.recording.service";
import { teamsRepo } from "../teams/teams.repo";
import { getLeagueRoleOrNull, assertLeagueRole } from "../../shared/permissions";
import type {
  MatchOverviewResponse,
  MatchLineupsResponse,
  FinalSheetsResponse,
  ProposeResultBody,
  VoteOnResultBody,
  AdminOverrideResultBody,
  AdminUpdateMatchBody,
  MatchResultSummary,
  MatchResultProposal,
  MatchTeamLineup,
  MatchPhase
} from "./matches.schemas";

function isLeagueCommissioner(user: AppUser, leagueId: number | null): boolean {
  if (user.role === "superadmin") return true;
  if (!leagueId) return false;
  const role = getLeagueRoleOrNull(leagueId, user.id);
  return role === "owner" || role === "commissioner";
}

function assertMatchAdmin(user: AppUser, leagueId: number | null) {
  if (user.role === "superadmin") return;
  if (!leagueId) {
    const err = new Error("Match is not associated with a league");
    (err as any).statusCode = 500;
    throw err;
  }
  assertLeagueRole(user, leagueId, ["owner", "commissioner"]);
}

export const matchesService = {
  /**
   * GET /matches/:matchId
   */
  getMatchOverview(matchId: number, user: AppUser): MatchOverviewResponse {
    const match = matchesRepo.getMatchById(matchId);
    if (!match) {
      const err = new Error("Match not found");
      (err as any).statusCode = 404;
      throw err;
    }

    const teamA = teamsRepo.getTeamById(match.teamAId);
    const teamB = teamsRepo.getTeamById(match.teamBId);

    if (!teamA || !teamB) {
      const err = new Error("Match teams not found");
      (err as any).statusCode = 500;
      throw err;
    }

    const isTeamA = teamA.userId === user.id;
    const isTeamB = teamB.userId === user.id;

    const resultSummary: MatchResultSummary = {
      scoreTeamA: match.scoreTeamA,
      scoreTeamB: match.scoreTeamB,
      winnerTeamId: match.winnerTeamId,
      status:
        match.status === "Completed"
          ? "Decided"
          : match.status === "Voided"
          ? "Voided"
          : match.status === "UnderReview"
          ? "UnderReview"
          : "Pending"
    };

    const rawResults = matchesRepo.listMatchResults(match.id);

    const proposals: MatchResultProposal[] = rawResults.map((r) => {
      const votes = matchesRepo.listResultVotes(r.id);
      const approvals = votes.filter((v) => v.vote === "up").length;
      const rejections = votes.filter((v) => v.vote === "down").length;

      const yourVoteRow = matchesRepo.getUserVoteForResult(r.id, user.id);

      return {
        id: r.id,
        matchId: r.matchId,
        submittedByTeamId: r.submittedByTeamId,
        submittedByUserId: r.submittedByUserId,
        createdAt: r.createdAt,
        status: r.status,
        scoreTeamA: r.scoreTeamA,
        scoreTeamB: r.scoreTeamB,
        winnerTeamId: r.winnerTeamId,
        notes: r.notes,
        approvals,
        rejections,
        yourVote: yourVoteRow ? yourVoteRow.vote : null
      };
    });

    return {
      match: {
        id: match.id,
        seasonId: match.seasonId,
        leagueId: match.leagueId,
        round: match.round,
        scheduledAt: match.scheduledAt,
        status: match.status,
        createdAt: match.createdAt
      },
      teamA: {
        teamId: teamA.id,
        name: teamA.name,
        logoUrl: teamA.logoUrl,
        managerUserId: teamA.userId,
        managerDisplayName: null
      },
      teamB: {
        teamId: teamB.id,
        name: teamB.name,
        logoUrl: teamB.logoUrl,
        managerUserId: teamB.userId,
        managerDisplayName: null
      },
      result: resultSummary,
      proposals,
      viewerPerspective: {
        isTeamA,
        isTeamB,
        isCommissioner: isLeagueCommissioner(user, match.leagueId ?? null)
      }
    };
  },

  /**
   * GET /matches/:matchId/lineups
   */
  getMatchLineups(matchId: number, user: AppUser): MatchLineupsResponse {
    const match = matchesRepo.getMatchById(matchId);
    if (!match) {
      const err = new Error("Match not found");
      (err as any).statusCode = 404;
      throw err;
    }

    const teamA = teamsRepo.getTeamById(match.teamAId);
    const teamB = teamsRepo.getTeamById(match.teamBId);
    if (!teamA || !teamB) {
      const err = new Error("Match teams not found");
      (err as any).statusCode = 500;
      throw err;
    }

    const yourTeamId =
      teamA.userId === user.id ? teamA.id : teamB.userId === user.id ? teamB.id : null;

    const phase: MatchPhase =
      match.status === "Completed"
        ? "Completed"
        : match.status === "InProgress" || match.status === "AwaitingResult"
        ? "Locked"
        : "PreLock";

    // If no round set, there's nothing to show yet.
    if (!Number.isInteger(match.round) || match.round == null) {
      const teamsLineups: MatchTeamLineup[] = [
        {
          teamId: teamA.id,
          name: teamA.name,
          lineupStatus: "NotSubmitted",
          slots: []
        },
        {
          teamId: teamB.id,
          name: teamB.name,
          lineupStatus: "NotSubmitted",
          slots: []
        }
      ];

      return {
        matchId: match.id,
        seasonId: match.seasonId,
        phase,
        yourTeamId,
        teams: teamsLineups
      };
    }

    const lineups = matchesRepo.getLineupsForMatch(
      match.seasonId,
      match.round,
      teamA.id,
      teamB.id
    );

    const teamALineupRow = lineups.find((l) => l.teamId === teamA.id);
    const teamBLineupRow = lineups.find((l) => l.teamId === teamB.id);

    const teamARoster = teamsRepo.listTeamRoster(teamA.id);
    const teamBRoster = teamsRepo.listTeamRoster(teamB.id);

    const teamALineup = buildTeamLineup(
      teamA,
      teamALineupRow,
      teamARoster,
      phase,
      yourTeamId
    );
    const teamBLineup = buildTeamLineup(
      teamB,
      teamBLineupRow,
      teamBRoster,
      phase,
      yourTeamId
    );

    return {
      matchId: match.id,
      seasonId: match.seasonId,
      phase,
      yourTeamId,
      teams: [teamALineup, teamBLineup]
    };
  },

  /**
   * GET /matches/:matchId/final-sheets
   */
  getFinalSheets(matchId: number, user: AppUser): FinalSheetsResponse {
    const match = matchesRepo.getMatchById(matchId);
    if (!match) {
      const err = new Error("Match not found");
      (err as any).statusCode = 404;
      throw err;
    }

    const teamA = teamsRepo.getTeamById(match.teamAId);
    const teamB = teamsRepo.getTeamById(match.teamBId);
    if (!teamA || !teamB) {
      const err = new Error("Match teams not found");
      (err as any).statusCode = 500;
      throw err;
    }

    const isTeamAUser = teamA.userId === user.id;
    const isTeamBUser = teamB.userId === user.id;

    // Only participants or league commissioners can view final sheets.
    if (!isTeamAUser && !isTeamBUser && !isLeagueCommissioner(user, match.leagueId ?? null)) {
      const err = new Error("You cannot view these sheets");
      (err as any).statusCode = 403;
      throw err;
    }

    return matchesRecordingService.getFinalSheets(matchId);
  },

  /**
   * POST /matches/:matchId/results/propose
   */
  proposeResult(
    matchId: number,
    user: AppUser,
    body: ProposeResultBody
  ): MatchOverviewResponse {
    const match = matchesRepo.getMatchById(matchId);
    if (!match) {
      const err = new Error("Match not found");
      (err as any).statusCode = 404;
      throw err;
    }

    const teamA = teamsRepo.getTeamById(match.teamAId);
    const teamB = teamsRepo.getTeamById(match.teamBId);
    if (!teamA || !teamB) {
      const err = new Error("Match teams not found");
      (err as any).statusCode = 500;
      throw err;
    }

    // Only participants (or league commissioners) can propose a result.
    const isTeamAUser = teamA.userId === user.id;
    const isTeamBUser = teamB.userId === user.id;

    if (!isTeamAUser && !isTeamBUser && !isLeagueCommissioner(user, match.leagueId ?? null)) {
      const err = new Error("You cannot submit results for this match");
      (err as any).statusCode = 403;
      throw err;
    }

    if (!Number.isInteger(body.scoreTeamA) || !Number.isInteger(body.scoreTeamB)) {
      const err = new Error("Scores must be integers");
      (err as any).statusCode = 400;
      throw err;
    }

    const submittedByTeamId = isTeamAUser
      ? teamA.id
      : isTeamBUser
      ? teamB.id
      : body.winnerTeamId ?? teamA.id;

    const gameBreakdownJson =
      body.gameBreakdown && body.gameBreakdown.length > 0
        ? JSON.stringify(body.gameBreakdown)
        : null;

    matchesRepo.createMatchResult({
      matchId: match.id,
      submittedByTeamId,
      submittedByUserId: user.id,
      scoreTeamA: body.scoreTeamA,
      scoreTeamB: body.scoreTeamB,
      winnerTeamId: body.winnerTeamId,
      notes: body.notes ?? null,
      gameBreakdownJson
    });

    return this.getMatchOverview(matchId, user);
  },

  /**
   * POST /matches/:matchId/results/:resultId/vote
   */
  voteOnResult(
    matchId: number,
    resultId: number,
    user: AppUser,
    body: VoteOnResultBody
  ): MatchOverviewResponse {
    if (body.vote !== "up" && body.vote !== "down") {
      const err = new Error("vote must be 'up' or 'down'");
      (err as any).statusCode = 400;
      throw err;
    }

    const match = matchesRepo.getMatchById(matchId);
    if (!match) {
      const err = new Error("Match not found");
      (err as any).statusCode = 404;
      throw err;
    }

    const result = matchesRepo.getResultById(match.id, resultId);
    if (!result) {
      const err = new Error("Result not found");
      (err as any).statusCode = 404;
      throw err;
    }

    matchesRepo.addResultVote({
      resultId: result.id,
      userId: user.id,
      vote: body.vote,
      comment: body.comment
    });

    return this.getMatchOverview(matchId, user);
  },

  /**
   * POST /matches/:matchId/admin/override-result
   */
  adminOverrideResult(
    matchId: number,
    user: AppUser,
    body: AdminOverrideResultBody
  ): MatchOverviewResponse {
    const match = matchesRepo.getMatchById(matchId);
    if (!match) {
      const err = new Error("Match not found");
      (err as any).statusCode = 404;
      throw err;
    }

    assertMatchAdmin(user, match.leagueId ?? null);

    const updated = matchesRepo.overrideMatchResult(
      match.id,
      body.winnerTeamId,
      body.scoreTeamA,
      body.scoreTeamB
    );
    if (!updated) {
      const err = new Error("Failed to override result");
      (err as any).statusCode = 500;
      throw err;
    }

    return this.getMatchOverview(matchId, user);
  },

  /**
   * POST /matches/:matchId/admin/reset
   */
  adminResetMatch(matchId: number, user: AppUser): void {
    const match = matchesRepo.getMatchById(matchId);
    if (!match) {
      const err = new Error("Match not found");
      (err as any).statusCode = 404;
      throw err;
    }

    assertMatchAdmin(user, match.leagueId ?? null);

    matchesRepo.resetMatch(match.id);
  },

  /**
   * PATCH /matches/:matchId/admin
   */
  adminUpdateMatch(
    matchId: number,
    user: AppUser,
    body: AdminUpdateMatchBody
  ): MatchOverviewResponse {
    const match = matchesRepo.getMatchById(matchId);
    if (!match) {
      const err = new Error("Match not found");
      (err as any).statusCode = 404;
      throw err;
    }

    assertMatchAdmin(user, match.leagueId ?? null);

    const updated = matchesRepo.updateMatchAdmin(match.id, body);
    if (!updated) {
      const err = new Error("Failed to update match");
      (err as any).statusCode = 500;
      throw err;
    }

    return this.getMatchOverview(matchId, user);
  }
};

function buildTeamLineup(
  team: { id: number; name: string },
  lineupRow:
    | ReturnType<typeof matchesRepo.getLineupsForMatch>[number]
    | undefined,
  roster: ReturnType<typeof teamsRepo.listTeamRoster>,
  phase: MatchPhase,
  yourTeamId: number | null
): MatchTeamLineup {
  const slots = matchesRepo.parseLineupSlots(lineupRow?.lineupJson ?? null);

  const isYours = yourTeamId === team.id;

  const rosterById = new Map(roster.map((r) => [r.pokemonId, r]));

  return {
    teamId: team.id,
    name: team.name,
    lineupStatus: lineupRow ? "Submitted" : "NotSubmitted",
    slots: slots.map((s) => {
      const r = s.pokemonId ? rosterById.get(s.pokemonId) : null;
      return {
        slot: s.slot,
        pokemonId: s.pokemonId,
        nickname: r?.nickname ?? null,
        speciesName: r?.speciesName ?? null,
        itemId: s.itemId ?? null
      };
    }),
    visibility: phase === "PreLock" ? (isYours ? "Full" : "Hidden") : "Full"
  };
}
