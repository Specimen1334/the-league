// apps/api/src/modules/marketplace/trades.schemas.ts

/**
 * Trade lifecycle.
 */
export type TradeStatus =
  | "Pending"
  | "Accepted"
  | "Rejected"
  | "Cancelled"
  | "Countered";

/**
 * Which side is offering a given asset – from the perspective of the
 * *original* trade offer.
 */
export type TradeSide = "from" | "to";

/**
 * What kind of asset is involved in the trade.
 */
export type TradeAssetType = "Pokemon" | "Item" | "Currency";

export type TradeAssetInput = {
  type: TradeAssetType;
  /**
   * For Pokémon assets – a specific roster instance.
   */
  pokemonInstanceId?: number;
  /**
   * For item assets – which item, and quantity.
   */
  itemId?: number;
  quantity?: number;
  /**
   * For currency assets – league/season currency units.
   */
  currencyAmount?: number;
};

export type TradeCreateBody = {
  /**
   * The team you’re sending this offer to.
   * The "from" team is inferred from the user’s team in that season.
   */
  toTeamId: number;

  /**
   * Assets your team is offering *away*.
   */
  fromAssets: TradeAssetInput[];

  /**
   * Assets you’re requesting *in return*.
   */
  toAssets: TradeAssetInput[];

  message?: string;
  expiresAt?: string | null; // ISO 8601 or null
};

/**
 * Counter-offer body.
 * The trade remains associated with the same two teams,
 * but the direction of assets can change.
 */
export type TradeCounterBody = {
  fromAssets: TradeAssetInput[];
  toAssets: TradeAssetInput[];
  message?: string;
  expiresAt?: string | null;
};

/**
 * List query for GET /seasons/:seasonId/marketplace/trades
 */
export type TradeListQuery = {
  direction?: "incoming" | "outgoing" | "all";
  status?: TradeStatus | "Any";
  page?: number;
  limit?: number;
};

/**
 * Asset as returned in responses, fully decorated.
 */
export type TradeAssetView = {
  id: number;
  side: TradeSide;
  type: TradeAssetType;

  // For Pokemon:
  pokemonInstanceId?: number;
  pokemonId?: number;
  pokemonName?: string | null;
  pokemonNickname?: string | null;

  // For Items:
  itemId?: number;
  itemName?: string | null;
  itemCategory?: string | null;
  quantity?: number;

  // For Currency:
  currencyAmount?: number;
};

export type TradeSummary = {
  id: number;
  seasonId: number;
  fromTeamId: number;
  toTeamId: number;
  status: TradeStatus;
  createdAt: string;
  updatedAt: string;
  expiresAt: string | null;
  lastMessageAt: string | null;

  /**
   * From the perspective of the current user’s team.
   */
  direction: "incoming" | "outgoing";

  fromTeamName: string | null;
  toTeamName: string | null;

  /**
   * Simple counts for list view.
   */
  assetCounts: {
    from: { pokemon: number; items: number; currency: number };
    to: { pokemon: number; items: number; currency: number };
  };
};

export type TradeListResponse = {
  page: number;
  limit: number;
  total: number;
  items: TradeSummary[];
};

export type TradeDetailResponse = {
  trade: {
    id: number;
    seasonId: number;
    fromTeamId: number;
    toTeamId: number;
    status: TradeStatus;
    createdAt: string;
    updatedAt: string;
    expiresAt: string | null;
    lastMessageAt: string | null;
    message: string | null;
  };

  fromTeam: {
    id: number;
    name: string | null;
  };
  toTeam: {
    id: number;
    name: string | null;
  };

  assets: TradeAssetView[];

  viewerPerspective: {
    teamId: number | null;
    direction: "incoming" | "outgoing" | "none";
    canAccept: boolean;
    canReject: boolean;
    canCancel: boolean;
    canCounter: boolean;
  };
};
