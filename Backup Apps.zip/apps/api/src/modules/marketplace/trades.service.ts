import type { AppUser } from "../../shared/types";
import { teamsRepo } from "../teams/teams.repo";
import { itemsRepo } from "./items.repo";
import { tradesRepo } from "./trades.repo";
import { seasonsRepo } from "../seasons/seasons.repo";
import { getLeagueRoleOrNull, assertLeagueRole } from "../../shared/permissions";

import type {
  TradeCreateBody,
  TradeCounterBody,
  TradeListQuery,
  TradeListResponse,
  TradeDetailResponse,
  TradeSummary,
  TradeAssetView,
  TradeAssetInput,
  TradeSide,
  TradeStatus,
  TradeAssetType
} from "./trades.schemas";

/* -------------------------------------------------------------------------- */
/* Utilities */
/* -------------------------------------------------------------------------- */

function assertPositiveInt(name: string, value: unknown): number {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) {
    const err = new Error(`${name} must be a positive integer`);
    (err as any).statusCode = 400;
    throw err;
  }
  return n;
}

function normaliseListQuery(
  raw: TradeListQuery
): Required<Pick<TradeListQuery, "page" | "limit">> &
  Omit<TradeListQuery, "page" | "limit"> {
  const page = Math.max(1, Number(raw.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(raw.limit) || 20));
  return { ...raw, page, limit };
}

function isLeagueCommissioner(user: AppUser, leagueId: number | null): boolean {
  if (user.role === "superadmin") return true;
  if (!leagueId) return false;
  const role = getLeagueRoleOrNull(leagueId, user.id);
  return role === "owner" || role === "commissioner";
}

/* -------------------------------------------------------------------------- */
/* Service */
/* -------------------------------------------------------------------------- */

export const tradesService = {
  /* -------------------------------- LIST --------------------------------- */

  listTrades(
    seasonIdParam: string,
    user: AppUser,
    rawQuery: TradeListQuery
  ): TradeListResponse {
    const seasonId = assertPositiveInt("seasonId", seasonIdParam);
    const query = normaliseListQuery(rawQuery);

    const season = seasonsRepo.getSeasonById(seasonId);
    if (!season) {
      const err = new Error("Season not found");
      (err as any).statusCode = 404;
      throw err;
    }

    const isCommissioner = isLeagueCommissioner(user, season.leagueId ?? null);

    const userTeam = !isCommissioner
      ? teamsRepo.getTeamBySeasonAndUser(seasonId, user.id)
      : null;

    if (!isCommissioner && !userTeam) {
      const err = new Error("You do not manage a team in this season");
      (err as any).statusCode = 403;
      throw err;
    }

    const trades = isCommissioner
      ? tradesRepo.listTradesForSeason(seasonId)
      : tradesRepo.listTradesForSeasonAndTeam(seasonId, userTeam!.id);

    const directionFilter = query.direction ?? "all";
    const statusFilter = (query.status ?? "Any") as TradeStatus | "Any";

    const filtered = trades.filter((t) => {
      if (!isCommissioner) {
        const dir = t.fromTeamId === userTeam!.id ? "outgoing" : "incoming";
        if (directionFilter !== "all" && dir !== directionFilter) return false;
      }
      if (statusFilter !== "Any" && t.status !== statusFilter) return false;
      return true;
    });

    const total = filtered.length;
    const start = (query.page - 1) * query.limit;
    const pageTrades = filtered.slice(start, start + query.limit);

    const summaries: TradeSummary[] = pageTrades.map((t) => {
      const fromTeam = teamsRepo.getTeamById(t.fromTeamId);
      const toTeam = teamsRepo.getTeamById(t.toTeamId);

      return {
        id: t.id,
        seasonId: t.seasonId,
        status: t.status,
        direction:
          userTeam && t.fromTeamId === userTeam.id ? "outgoing" : "incoming",
        createdAt: t.createdAt,
        updatedAt: t.updatedAt,
        otherTeam: isCommissioner
          ? null
          : t.fromTeamId === userTeam!.id
          ? toTeam
            ? { teamId: toTeam.id, name: toTeam.name, logoUrl: toTeam.logoUrl }
            : null
          : fromTeam
          ? { teamId: fromTeam.id, name: fromTeam.name, logoUrl: fromTeam.logoUrl }
          : null
      };
    });

    return {
      seasonId,
      trades: summaries,
      page: query.page,
      limit: query.limit,
      total
    };
  },

  /* ------------------------------- DETAIL -------------------------------- */

  getTradeDetail(
    seasonIdParam: string,
    tradeIdParam: string,
    user: AppUser
  ): TradeDetailResponse {
    const seasonId = assertPositiveInt("seasonId", seasonIdParam);
    const tradeId = assertPositiveInt("tradeId", tradeIdParam);

    const season = seasonsRepo.getSeasonById(seasonId);
    if (!season) {
      const err = new Error("Season not found");
      (err as any).statusCode = 404;
      throw err;
    }

    const trade = tradesRepo.getTradeById(tradeId);
    if (!trade || trade.seasonId !== seasonId) {
      const err = new Error("Trade not found");
      (err as any).statusCode = 404;
      throw err;
    }

    const isCommissioner = isLeagueCommissioner(user, season.leagueId ?? null);

    const userTeam = !isCommissioner
      ? teamsRepo.getTeamBySeasonAndUser(seasonId, user.id)
      : null;

    if (
      !isCommissioner &&
      (!userTeam ||
        (userTeam.id !== trade.fromTeamId &&
          userTeam.id !== trade.toTeamId))
    ) {
      const err = new Error("You cannot view this trade");
      (err as any).statusCode = 403;
      throw err;
    }

    const fromTeam = teamsRepo.getTeamById(trade.fromTeamId);
    const toTeam = teamsRepo.getTeamById(trade.toTeamId);

    const fromAssets = tradesRepo
      .listTradeAssets(trade.id, "From")
      .map(toAssetView);
    const toAssets = tradesRepo
      .listTradeAssets(trade.id, "To")
      .map(toAssetView);

    return {
      trade: {
        id: trade.id,
        seasonId: trade.seasonId,
        status: trade.status,
        createdAt: trade.createdAt,
        updatedAt: trade.updatedAt,
        fromTeam: fromTeam
          ? { teamId: fromTeam.id, name: fromTeam.name, logoUrl: fromTeam.logoUrl }
          : null,
        toTeam: toTeam
          ? { teamId: toTeam.id, name: toTeam.name, logoUrl: toTeam.logoUrl }
          : null,
        fromAssets,
        toAssets
      }
    };
  },

  /* ------------------------------- CREATE -------------------------------- */

  createTrade(
    seasonIdParam: string,
    user: AppUser,
    body: TradeCreateBody
  ): TradeDetailResponse {
    const seasonId = assertPositiveInt("seasonId", seasonIdParam);

    const season = seasonsRepo.getSeasonById(seasonId);
    if (!season) {
      const err = new Error("Season not found");
      (err as any).statusCode = 404;
      throw err;
    }

    const fromTeam = teamsRepo.getTeamBySeasonAndUser(seasonId, user.id);
    if (!fromTeam) {
      const err = new Error("You do not manage a team in this season");
      (err as any).statusCode = 403;
      throw err;
    }

    const toTeamId = assertPositiveInt("toTeamId", body.toTeamId);
    if (toTeamId === fromTeam.id) {
      const err = new Error("Cannot trade with yourself");
      (err as any).statusCode = 400;
      throw err;
    }

    const toTeam = teamsRepo.getTeamById(toTeamId);
    if (!toTeam || toTeam.seasonId !== seasonId) {
      const err = new Error("Target team not found in this season");
      (err as any).statusCode = 404;
      throw err;
    }

    const trade = tradesRepo.createTrade({
      seasonId,
      fromTeamId: fromTeam.id,
      toTeamId,
      status: "Pending"
    });

    for (const a of body.fromAssets ?? []) {
      tradesRepo.addTradeAsset(trade.id, toAssetRow("From", a));
    }
    for (const a of body.toAssets ?? []) {
      tradesRepo.addTradeAsset(trade.id, toAssetRow("To", a));
    }

    return this.getTradeDetail(seasonIdParam, String(trade.id), user);
  },

  /* ----------------------------- MODERATION ------------------------------- */

  acceptTrade(seasonIdParam: string, tradeIdParam: string, user: AppUser) {
    return actOnTrade(seasonIdParam, tradeIdParam, user, "Accepted");
  },

  rejectTrade(seasonIdParam: string, tradeIdParam: string, user: AppUser) {
    return actOnTrade(seasonIdParam, tradeIdParam, user, "Rejected");
  },

  counterTrade(
    seasonIdParam: string,
    tradeIdParam: string,
    user: AppUser,
    body: TradeCounterBody
  ) {
    const res = actOnTrade(seasonIdParam, tradeIdParam, user, "Countered");

    const tradeId = assertPositiveInt("tradeId", tradeIdParam);
    tradesRepo.clearTradeAssets(tradeId);

    for (const a of body.fromAssets ?? []) {
      tradesRepo.addTradeAsset(tradeId, toAssetRow("From", a));
    }
    for (const a of body.toAssets ?? []) {
      tradesRepo.addTradeAsset(tradeId, toAssetRow("To", a));
    }

    return res;
  }
};

/* -------------------------------------------------------------------------- */
/* Helpers */
/* -------------------------------------------------------------------------- */

function actOnTrade(
  seasonIdParam: string,
  tradeIdParam: string,
  user: AppUser,
  nextStatus: TradeStatus
): TradeDetailResponse {
  const seasonId = assertPositiveInt("seasonId", seasonIdParam);
  const tradeId = assertPositiveInt("tradeId", tradeIdParam);

  const season = seasonsRepo.getSeasonById(seasonId);
  if (!season) {
    const err = new Error("Season not found");
    (err as any).statusCode = 404;
    throw err;
  }

  const trade = tradesRepo.getTradeById(tradeId);
  if (!trade || trade.seasonId !== seasonId) {
    const err = new Error("Trade not found");
    (err as any).statusCode = 404;
    throw err;
  }

  const isCommissioner = isLeagueCommissioner(user, season.leagueId ?? null);
  const userTeam = teamsRepo.getTeamBySeasonAndUser(seasonId, user.id);

  if (
    !isCommissioner &&
    (!userTeam || userTeam.id !== trade.toTeamId)
  ) {
    const err = new Error("You cannot act on this trade");
    (err as any).statusCode = 403;
    throw err;
  }

  tradesRepo.setTradeStatus(trade.id, nextStatus);

  if (nextStatus === "Accepted") {
    tradesRepo.executeTrade(trade.id);
  }

  return tradesService.getTradeDetail(seasonIdParam, tradeIdParam, user);
}

function toAssetView(row: any): TradeAssetView {
  if (row.assetType === "Item") {
    const item = itemsRepo.getItemById(row.assetId);
    return {
      assetType: "Item",
      assetId: row.assetId,
      quantity: row.quantity,
      label: item ? item.name : "Unknown Item"
    };
  }
  return {
    assetType: row.assetType as TradeAssetType,
    assetId: row.assetId,
    quantity: row.quantity,
    label: "Asset"
  };
}

function toAssetRow(side: TradeSide, a: TradeAssetInput) {
  return {
    side,
    assetType: a.assetType,
    assetId: a.assetId,
    quantity: a.quantity ?? 1
  };
}
