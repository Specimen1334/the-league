// apps/api/src/modules/marketplace/items.service.ts
import { itemsRepo } from "./items.repo";

/**
 * Lightweight items service.
 * Currently not wired to a public route in marketplace.ts, but:
 * - tradesService can use it to decorate trade assets
 * - future "shop" endpoints can use these view models directly
 */

export type ItemSummary = {
  id: number;
  name: string;
  category: string | null;
  description: string | null;
  baseCost: number | null;
  tags: string[];
  spriteUrl: string | null;
};

export type SeasonItemSummary = ItemSummary & {
  seasonId: number;
  price: number | null;
  isEnabled: boolean;
};

export const itemsService = {
  getItem(id: number): ItemSummary | undefined {
    const row = itemsRepo.getItemById(id);
    if (!row) return undefined;

    return {
      id: row.id,
      name: row.name,
      category: row.category,
      description: row.description,
      baseCost: row.baseCost,
      tags: safeParseStringArray(row.tagsJson),
      spriteUrl: row.spriteUrl
    };
  },

  listAllItems(): ItemSummary[] {
    const rows = itemsRepo.listAllItems();
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      category: row.category,
      description: row.description,
      baseCost: row.baseCost,
      tags: safeParseStringArray(row.tagsJson),
      spriteUrl: row.spriteUrl
    }));
  },

  listSeasonItems(seasonId: number): SeasonItemSummary[] {
    const seasonItems = itemsRepo.listSeasonItems(seasonId);
    const byId = new Map(
      itemsRepo.listAllItems().map((i) => [i.id, i])
    );

    return seasonItems.map((si) => {
      const base = byId.get(si.itemId);
      return {
        id: si.itemId,
        seasonId: si.seasonId,
        price: si.price,
        isEnabled: si.isEnabled,
        name: base?.name ?? `Item #${si.itemId}`,
        category: base?.category ?? null,
        description: base?.description ?? null,
        baseCost: base?.baseCost ?? null,
        tags: safeParseStringArray(base?.tagsJson ?? null),
        spriteUrl: base?.spriteUrl ?? null
      };
    });
  }
};

function safeParseStringArray(raw: string | null): string[] {
  if (!raw) return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v.map(String) : [];
  } catch {
    return [];
  }
}
