// apps/api/src/routes/seasons/seasons.matches.ts
import type { FastifyInstance } from "fastify";
import type { RequireAuthHook } from "../../shared/permissions";
import { matchesService } from "../../modules/matches/matches.service";
import { toErrorResponse } from "../../shared/errors";
import type {
  SeasonMatchesQuery,
  SeasonMatchesResponse,
  SeasonMatchCalendarResponse,
  GenerateSeasonMatchesBody
} from "../../modules/matches/matches.schemas";

export function registerSeasonMatchesRoutes(
  app: FastifyInstance,
  deps: { requireAuth: RequireAuthHook }
) {
  const { requireAuth } = deps;

  // GET /seasons/:seasonId/matches – list/filter matches for a season
  app.get<{
    Params: { seasonId: string };
    Querystring: SeasonMatchesQuery;
    Reply: SeasonMatchesResponse;
  }>(
    "/seasons/:seasonId/matches",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const result = matchesService.listSeasonMatches(
          seasonId,
          user,
          request.query ?? {}
        );
        reply.send(result);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /seasons/:seasonId/matches/calendar – grouped calendar view
  app.get<{
    Params: { seasonId: string };
    Reply: SeasonMatchCalendarResponse;
  }>(
    "/seasons/:seasonId/matches/calendar",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const calendar = matchesService.getSeasonMatchCalendar(seasonId, user);
        reply.send(calendar);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/matches/generate – generate schedule (commissioner)
  app.post<{
    Params: { seasonId: string };
    Body: GenerateSeasonMatchesBody;
  }>(
    "/seasons/:seasonId/matches/generate",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        matchesService.generateSeasonMatches(
          seasonId,
          user,
          request.body ?? {}
        );
        reply.code(204).send();
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );
}
