// apps/api/src/routes/draft.ts
import type { FastifyInstance } from "fastify";
import type { RequireAuthHook } from "../shared/permissions";
import { toErrorResponse } from "../shared/errors";
import { draftService } from "../modules/draft/draft.service";

import type {
  DraftLobbyResponse,
  DraftReadyResponse,
  DraftStateResponse,
  DraftPoolQuery,
  DraftPoolResponse,
  MyDraftResponse,
  DraftWatchlistBody,
  DraftWatchlistResponse,
  DraftPickBody,
  DraftResultsResponse,
  DraftTeamResultsResponse,
  DraftExportFormat,
  AdminForcePickBody
} from "../modules/draft/draft.schemas";

export function registerDraftRoutes(
  app: FastifyInstance,
  deps: { requireAuth: RequireAuthHook }
) {
  const { requireAuth } = deps;

  // Helper: parse seasonId safely
  function parseSeasonId(raw: string, reply: any): number | null {
    const seasonId = Number(raw);
    if (!Number.isInteger(seasonId) || seasonId <= 0) {
      reply.code(400).send({
        error: "BadRequest",
        message: "Invalid seasonId"
      } as any);
      return null;
    }
    return seasonId;
  }

  // ───────────────────────────
  // Draft meta / lobby
  // ───────────────────────────

  // GET /seasons/:seasonId/draft/lobby
  app.get<{
    Params: { seasonId: string };
    Reply: DraftLobbyResponse;
  }>(
    "/seasons/:seasonId/draft/lobby",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const lobby = draftService.getLobby(seasonId, user);
        reply.send(lobby);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/draft/ready
  app.post<{
    Params: { seasonId: string };
    Reply: DraftReadyResponse;
  }>(
    "/seasons/:seasonId/draft/ready",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const res = draftService.toggleReady(seasonId, user);
        reply.send(res);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // ───────────────────────────
  // Live draft state and views
  // ───────────────────────────

  // GET /seasons/:seasonId/draft/state
  app.get<{
    Params: { seasonId: string };
    Reply: DraftStateResponse;
  }>(
    "/seasons/:seasonId/draft/state",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const state = draftService.getState(seasonId, user);
        reply.send(state);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /seasons/:seasonId/draft/pool
  app.get<{
    Params: { seasonId: string };
    Querystring: DraftPoolQuery;
    Reply: DraftPoolResponse;
  }>(
    "/seasons/:seasonId/draft/pool",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const pool = draftService.getPool(
          seasonId,
          user,
          request.query ?? {}
        );
        reply.send(pool);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /seasons/:seasonId/draft/my
  app.get<{
    Params: { seasonId: string };
    Reply: MyDraftResponse;
  }>(
    "/seasons/:seasonId/draft/my",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const my = draftService.getMyDraft(seasonId, user);
        reply.send(my);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // ───────────────────────────
  // Actions: watchlist & picks
  // ───────────────────────────

  // POST /seasons/:seasonId/draft/watchlist
  app.post<{
    Params: { seasonId: string };
    Body: DraftWatchlistBody;
    Reply: DraftWatchlistResponse;
  }>(
    "/seasons/:seasonId/draft/watchlist",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const list = draftService.updateWatchlist(
          seasonId,
          user,
          request.body
        );
        reply.send(list);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/draft/pick
  app.post<{
    Params: { seasonId: string };
    Body: DraftPickBody;
    Reply: DraftStateResponse;
  }>(
    "/seasons/:seasonId/draft/pick",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const state = draftService.makePick(seasonId, user, request.body);
        reply.send(state);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // ───────────────────────────
  // Results & exports
  // ───────────────────────────

  // GET /seasons/:seasonId/draft/results
  app.get<{
    Params: { seasonId: string };
    Reply: DraftResultsResponse;
  }>(
    "/seasons/:seasonId/draft/results",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const results = draftService.getResults(seasonId, user);
        reply.send(results);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /seasons/:seasonId/draft/results/:teamId
  app.get<{
    Params: { seasonId: string; teamId: string };
    Reply: DraftTeamResultsResponse;
  }>(
    "/seasons/:seasonId/draft/results/:teamId",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        const teamId = Number(request.params.teamId);
        if (!seasonId) return;
        if (!Number.isInteger(teamId) || teamId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid teamId"
          } as any);
          return;
        }

        const user = request.user!;
        const results = draftService.getTeamResults(
          seasonId,
          teamId,
          user
        );
        reply.send(results);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /seasons/:seasonId/draft/results/export/showdown
  app.get<{
    Params: { seasonId: string };
  }>(
    "/seasons/:seasonId/draft/results/export/showdown",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const text = draftService.exportResults(
          seasonId,
          user,
          "showdown" as DraftExportFormat
        );

        reply
          .header("Content-Type", "text/plain; charset=utf-8")
          .send(text);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /seasons/:seasonId/draft/results/export/csv
  app.get<{
    Params: { seasonId: string };
  }>(
    "/seasons/:seasonId/draft/results/export/csv",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const csv = draftService.exportResults(
          seasonId,
          user,
          "csv" as DraftExportFormat
        );

        reply
          .header("Content-Type", "text/csv; charset=utf-8")
          .send(csv);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // ───────────────────────────
  // Commissioner controls
  // ───────────────────────────

  // POST /seasons/:seasonId/draft/admin/start
  app.post<{
    Params: { seasonId: string };
    Reply: DraftStateResponse;
  }>(
    "/seasons/:seasonId/draft/admin/start",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const state = draftService.adminStartDraft(seasonId, user);
        reply.send(state);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/draft/admin/pause
  app.post<{
    Params: { seasonId: string };
    Reply: DraftStateResponse;
  }>(
    "/seasons/:seasonId/draft/admin/pause",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const state = draftService.adminPauseDraft(seasonId, user);
        reply.send(state);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/draft/admin/end
  app.post<{
    Params: { seasonId: string };
    Reply: DraftStateResponse;
  }>(
    "/seasons/:seasonId/draft/admin/end",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const state = draftService.adminEndDraft(seasonId, user);
        reply.send(state);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/draft/admin/force-pick
  app.post<{
    Params: { seasonId: string };
    Body: AdminForcePickBody;
    Reply: DraftStateResponse;
  }>(
    "/seasons/:seasonId/draft/admin/force-pick",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const state = draftService.adminForcePick(
          seasonId,
          user,
          request.body
        );
        reply.send(state);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/draft/admin/undo-last
  app.post<{
    Params: { seasonId: string };
    Reply: DraftStateResponse;
  }>(
    "/seasons/:seasonId/draft/admin/undo-last",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = parseSeasonId(request.params.seasonId, reply);
        if (!seasonId) return;

        const user = request.user!;
        const state = draftService.adminUndoLast(seasonId, user);
        reply.send(state);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );
}
