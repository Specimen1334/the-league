// apps/api/src/routes/marketplace.ts
import type { FastifyInstance } from "fastify";
import type { RequireAuthHook } from "../shared/permissions.";
import { toErrorResponse } from "../shared/errors";

import { tradesService } from "../modules/marketplace/trades.service";
import { itemsService } from "../modules/marketplace/items.service";

import type {
  MarketplaceTeamsResponse,
  MarketplaceTeamRosterResponse,
  CreateTradeBody,
  TradeListQuery,
  TradeListResponse,
  TradeDetailResponse,
  TradeActionBody,
  FreeAgentsListResponse,
  FreeAgentClaimBody,
  ProcessWaiversResponse,
  ShopItemsResponse,
  ShopPurchaseBody,
  ShopSellBody,
  WatchlistResponse,
  WatchlistUpdateBody,
  MarketplaceSettingsResponse,
  MarketplaceSettingsUpdateBody
} from "../modules/marketplace/trades.schemas";

export function registerMarketplaceRoutes(
  app: FastifyInstance,
  deps: { requireAuth: RequireAuthHook }
) {
  const { requireAuth } = deps;

  // ───────────────────────────
  // Trade Centre – team summaries & rosters
  // ───────────────────────────

  // GET /seasons/:seasonId/marketplace/teams
  app.get<{
    Params: { seasonId: string };
    Reply: MarketplaceTeamsResponse;
  }>(
    "/seasons/:seasonId/marketplace/teams",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const result = tradesService.listTeamsForMarketplace(seasonId, user);
        reply.send(result);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /seasons/:seasonId/marketplace/teams/:teamId/roster
  app.get<{
    Params: { seasonId: string; teamId: string };
    Reply: MarketplaceTeamRosterResponse;
  }>(
    "/seasons/:seasonId/marketplace/teams/:teamId/roster",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        const teamId = Number(request.params.teamId);
        if (
          !Number.isInteger(seasonId) ||
          seasonId <= 0 ||
          !Number.isInteger(teamId) ||
          teamId <= 0
        ) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId or teamId"
          } as any);
          return;
        }

        const user = request.user!;
        const roster = tradesService.getTeamRosterForMarketplace(
          seasonId,
          teamId,
          user
        );
        reply.send(roster);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // ───────────────────────────
  // Trades
  // ───────────────────────────

  // POST /seasons/:seasonId/marketplace/trades
  app.post<{
    Params: { seasonId: string };
    Body: CreateTradeBody;
    Reply: TradeDetailResponse;
  }>(
    "/seasons/:seasonId/marketplace/trades",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const trade = tradesService.createTradeOffer(
          seasonId,
          user,
          request.body
        );
        reply.code(201).send(trade);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /seasons/:seasonId/marketplace/trades
  app.get<{
    Params: { seasonId: string };
    Querystring: TradeListQuery;
    Reply: TradeListResponse;
  }>(
    "/seasons/:seasonId/marketplace/trades",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const list = tradesService.listTradesForTeam(
          seasonId,
          user,
          request.query ?? {}
        );
        reply.send(list);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /seasons/:seasonId/marketplace/trades/:tradeId
  app.get<{
    Params: { seasonId: string; tradeId: string };
    Reply: TradeDetailResponse;
  }>(
    "/seasons/:seasonId/marketplace/trades/:tradeId",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        const tradeId = Number(request.params.tradeId);
        if (
          !Number.isInteger(seasonId) ||
          seasonId <= 0 ||
          !Number.isInteger(tradeId) ||
          tradeId <= 0
        ) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId or tradeId"
          } as any);
          return;
        }

        const user = request.user!;
        const trade = tradesService.getTradeDetail(seasonId, tradeId, user);
        reply.send(trade);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/marketplace/trades/:tradeId/accept
  app.post<{
    Params: { seasonId: string; tradeId: string };
    Body: TradeActionBody;
    Reply: TradeDetailResponse;
  }>(
    "/seasons/:seasonId/marketplace/trades/:tradeId/accept",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        const tradeId = Number(request.params.tradeId);
        if (
          !Number.isInteger(seasonId) ||
          seasonId <= 0 ||
          !Number.isInteger(tradeId) ||
          tradeId <= 0
        ) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId or tradeId"
          } as any);
          return;
        }

        const user = request.user!;
        const trade = tradesService.acceptTrade(
          seasonId,
          tradeId,
          user,
          request.body
        );
        reply.send(trade);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/marketplace/trades/:tradeId/reject
  app.post<{
    Params: { seasonId: string; tradeId: string };
    Body: TradeActionBody;
    Reply: TradeDetailResponse;
  }>(
    "/seasons/:seasonId/marketplace/trades/:tradeId/reject",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        const tradeId = Number(request.params.tradeId);
        if (
          !Number.isInteger(seasonId) ||
          seasonId <= 0 ||
          !Number.isInteger(tradeId) ||
          tradeId <= 0
        ) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId or tradeId"
          } as any);
          return;
        }

        const user = request.user!;
        const trade = tradesService.rejectTrade(
          seasonId,
          tradeId,
          user,
          request.body
        );
        reply.send(trade);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/marketplace/trades/:tradeId/counter
  app.post<{
    Params: { seasonId: string; tradeId: string };
    Body: CreateTradeBody;
    Reply: TradeDetailResponse;
  }>(
    "/seasons/:seasonId/marketplace/trades/:tradeId/counter",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        const tradeId = Number(request.params.tradeId);
        if (
          !Number.isInteger(seasonId) ||
          seasonId <= 0 ||
          !Number.isInteger(tradeId) ||
          tradeId <= 0
        ) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId or tradeId"
          } as any);
          return;
        }

        const user = request.user!;
        const trade = tradesService.counterTrade(
          seasonId,
          tradeId,
          user,
          request.body
        );
        reply.send(trade);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // ───────────────────────────
  // Free agency / waivers
  // ───────────────────────────

  // GET /seasons/:seasonId/free-agents
  app.get<{
    Params: { seasonId: string };
    Reply: FreeAgentsListResponse;
  }>(
    "/seasons/:seasonId/free-agents",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const result = itemsService.listFreeAgents(seasonId, user);
        reply.send(result);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/free-agents/claim
  app.post<{
    Params: { seasonId: string };
    Body: FreeAgentClaimBody;
  }>(
    "/seasons/:seasonId/free-agents/claim",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        itemsService.submitFreeAgentClaim(seasonId, user, request.body);
        reply.code(202).send({ ok: true });
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/free-agents/process-waivers
  app.post<{
    Params: { seasonId: string };
    Reply: ProcessWaiversResponse;
  }>(
    "/seasons/:seasonId/free-agents/process-waivers",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const res = itemsService.processWaivers(seasonId, user);
        reply.send(res);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // ───────────────────────────
  // Item Shop
  // ───────────────────────────

  // GET /seasons/:seasonId/shop/items
  app.get<{
    Params: { seasonId: string };
    Reply: ShopItemsResponse;
  }>(
    "/seasons/:seasonId/shop/items",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const items = itemsService.listShopItems(seasonId, user);
        reply.send(items);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/shop/purchase
  app.post<{
    Params: { seasonId: string };
    Body: ShopPurchaseBody;
  }>(
    "/seasons/:seasonId/shop/purchase",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        itemsService.purchaseItem(seasonId, user, request.body);
        reply.code(201).send({ ok: true });
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/shop/sell
  app.post<{
    Params: { seasonId: string };
    Body: ShopSellBody;
  }>(
    "/seasons/:seasonId/shop/sell",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        itemsService.sellItem(seasonId, user, request.body);
        reply.code(201).send({ ok: true });
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // ───────────────────────────
  // Watchlist
  // ───────────────────────────

  // GET /seasons/:seasonId/watchlist
  app.get<{
    Params: { seasonId: string };
    Reply: WatchlistResponse;
  }>(
    "/seasons/:seasonId/watchlist",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const list = itemsService.getWatchlist(seasonId, user);
        reply.send(list);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /seasons/:seasonId/watchlist
  app.post<{
    Params: { seasonId: string };
    Body: WatchlistUpdateBody;
    Reply: WatchlistResponse;
  }>(
    "/seasons/:seasonId/watchlist",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const list = itemsService.updateWatchlist(
          seasonId,
          user,
          request.body
        );
        reply.send(list);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // ───────────────────────────
  // Marketplace settings (commissioner)
  // ───────────────────────────

  // GET /seasons/:seasonId/marketplace/settings
  app.get<{
    Params: { seasonId: string };
    Reply: MarketplaceSettingsResponse;
  }>(
    "/seasons/:seasonId/marketplace/settings",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const settings = itemsService.getMarketplaceSettings(seasonId, user);
        reply.send(settings);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // PATCH /seasons/:seasonId/marketplace/settings
  app.patch<{
    Params: { seasonId: string };
    Body: MarketplaceSettingsUpdateBody;
    Reply: MarketplaceSettingsResponse;
  }>(
    "/seasons/:seasonId/marketplace/settings",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const seasonId = Number(request.params.seasonId);
        if (!Number.isInteger(seasonId) || seasonId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid seasonId"
          } as any);
          return;
        }

        const user = request.user!;
        const settings = itemsService.updateMarketplaceSettings(
          seasonId,
          user,
          request.body
        );
        reply.send(settings);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );
}
