// apps/api/src/routes/inbox.ts
import type { FastifyInstance } from "fastify";
import type { RequireAuthHook } from "../shared/permissions";
import { inboxService } from "../modules/inbox/inbox.service";
import { toErrorResponse } from "../shared/errors";
import type {
  InboxListQuery,
  InboxListResponse,
  InboxThreadResponse,
  SendInboxMessageBody,
  ReplyInboxMessageBody
} from "../modules/inbox/inbox.schemas";

export function registerInboxRoutes(
  app: FastifyInstance,
  deps: { requireAuth: RequireAuthHook }
) {
  const { requireAuth } = deps;

  // GET /inbox – list inbox threads/items for the current user
  app.get<{
    Querystring: InboxListQuery;
    Reply: InboxListResponse;
  }>(
    "/inbox",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const user = request.user!;
        const result = inboxService.listInbox(user, request.query ?? {});
        reply.send(result);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /inbox/unread-count – lightweight badge counter
  app.get(
    "/inbox/unread-count",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const user = request.user!;
        const count = inboxService.getUnreadCount(user);
        reply.send({ unreadCount: count });
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // GET /inbox/threads/:threadId – full thread (messages, metadata)
  app.get<{
    Params: { threadId: string };
    Reply: InboxThreadResponse;
  }>(
    "/inbox/threads/:threadId",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const threadId = Number(request.params.threadId);
        if (!Number.isInteger(threadId) || threadId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid threadId"
          } as any);
          return;
        }

        const user = request.user!;
        const thread = inboxService.getThread(user, threadId);
        reply.send(thread);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /inbox/threads – start a new conversation (DM/invite/etc.)
  app.post<{
    Body: SendInboxMessageBody;
    Reply: InboxThreadResponse;
  }>(
    "/inbox/threads",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const user = request.user!;
        const thread = inboxService.sendMessage(user, request.body);
        reply.code(201).send(thread);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /inbox/threads/:threadId/reply – reply in an existing thread
  app.post<{
    Params: { threadId: string };
    Body: ReplyInboxMessageBody;
    Reply: InboxThreadResponse;
  }>(
    "/inbox/threads/:threadId/reply",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const threadId = Number(request.params.threadId);
        if (!Number.isInteger(threadId) || threadId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid threadId"
          } as any);
          return;
        }

        const user = request.user!;
        const thread = inboxService.replyToThread(user, threadId, request.body);
        reply.send(thread);
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /inbox/threads/:threadId/mark-read – mark thread as read
  app.post<{
    Params: { threadId: string };
  }>(
    "/inbox/threads/:threadId/mark-read",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const threadId = Number(request.params.threadId);
        if (!Number.isInteger(threadId) || threadId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid threadId"
          } as any);
          return;
        }

        const user = request.user!;
        inboxService.markThreadRead(user, threadId);
        reply.code(204).send();
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );

  // POST /inbox/threads/:threadId/archive – archive a conversation
  app.post<{
    Params: { threadId: string };
  }>(
    "/inbox/threads/:threadId/archive",
    { preHandler: requireAuth },
    async (request, reply) => {
      try {
        const threadId = Number(request.params.threadId);
        if (!Number.isInteger(threadId) || threadId <= 0) {
          reply.code(400).send({
            error: "BadRequest",
            message: "Invalid threadId"
          } as any);
          return;
        }

        const user = request.user!;
        inboxService.archiveThread(user, threadId);
        reply.code(204).send();
      } catch (err) {
        const { statusCode, payload } = toErrorResponse(err);
        reply.code(statusCode).send(payload);
      }
    }
  );
}
