"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type MeUser = {
  id: number;
  username: string;
  displayName?: string | null;
  email?: string | null;
  role: string;
  createdAt: string;
};

type MeResponse = {
  user: MeUser | null;
};

export function NavAuthControls() {
  const [user, setUser] = useState<MeUser | null | undefined>(undefined);
  const [loggingOut, setLoggingOut] = useState(false);

  // Fetch current user from the backend
  useEffect(() => {
    let cancelled = false;

    async function loadMe() {
      try {
        const res = await fetch("/api/auth/me", {
          credentials: "include"
        });

        if (!res.ok) {
          if (!cancelled) setUser(null);
          return;
        }

        const data: MeResponse = await res.json();
        if (!cancelled) {
          setUser(data.user);
        }
      } catch {
        if (!cancelled) setUser(null);
      }
    }

    loadMe();

    return () => {
      cancelled = true;
    };
  }, []);

  // While loading, don’t render anything special
  if (user === undefined) {
    return null;
  }

  // Not logged in → show Login / Sign up
  if (!user) {
    return (
      <>
        <Link href="/login" className="btn btn-sm btn-secondary">
          Login
        </Link>
        <Link href="/register" className="btn btn-sm btn-primary">
          Sign up
        </Link>
      </>
    );
  }

  // Logged in → show greeting + Logout
  async function handleLogout() {
    if (loggingOut) return;
    setLoggingOut(true);
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include"
      });
      // Hard reload to reset all client state + middleware will send us to /login
      window.location.href = "/login";
    } catch {
      setLoggingOut(false);
    }
  }

  const label = user.displayName?.trim() || user.username;

  return (
    <>
      <span className="text-sm text-muted">Hi, {label}</span>
      <button
        onClick={handleLogout}
        className="btn btn-sm btn-ghost"
        disabled={loggingOut}
      >
        {loggingOut ? "Logging out..." : "Log out"}
      </button>
    </>
  );
}
