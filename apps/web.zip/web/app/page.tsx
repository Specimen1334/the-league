﻿export default function HomePage() {
  return (
    <main>
      <h1>The League</h1>
      <p>Home page placeholder.</p>
    </main>
  );
}
