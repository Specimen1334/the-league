﻿// apps/web/app/layout.tsx
import "./globals.css";
import Link from "next/link";
import { ThemeSwitcher } from "./ThemeSwitcher";
import { NavAuthControls } from "./NavAuthControls";


export const metadata = {
  title: "The League",
  description: "Fantasy league manager"
};

export default function RootLayout(props: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="app-root" data-theme="light">
        <div className="app-shell">
          <header
            style={{
              marginBottom: "1.5rem"
            }}
          >
            <nav
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "1rem"
              }}
            >
              <Link href="/" className="heading-sm">
                The League
              </Link>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.75rem"
                }}
              >
                {/* Theme switcher */}
                <ThemeSwitcher />

                {/* Main app navigation */}
                <Link href="/dashboard" className="btn btn-sm btn-ghost">
                  Dashboard
                </Link>
                <Link href="/leagues" className="btn btn-sm btn-ghost">
                  Leagues
                </Link>
                <Link href="/pokedex" className="btn btn-sm btn-ghost">
                  Pokedex
                </Link>
                <Link href="/inbox" className="btn btn-sm btn-ghost">
                  Inbox
                </Link>
                <Link href="/profile" className="btn btn-sm btn-ghost">
                  Profile
                </Link>

{/* Auth-aware controls – changes when logged in */}
<NavAuthControls />

              </div>
            </nav>
          </header>

          {props.children}
        </div>
      </body>
    </html>
  );
}
