"use client";

import { useEffect, useMemo, useState, FormEvent } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";

/**
 * Web -> API goes through Next proxy at /api
 * (direct /leagues or /auth will 404)
 */
const API_BASE_URL = "/api";

type LeagueVisibility =
  | "public"
  | "private"
  | "password-protected"
  | "invite-only"
  | string;

type LeagueDetail = {
  id: number;
  name: string;
  description: string | null;
  logoUrl: string | null;
  visibility: LeagueVisibility;
  ownerUserId: number;
  ownerUsername: string | null;
  memberCount: number;
  activeSeasonCount: number;
  createdAt: string;

  // backend fields
  isMember: boolean;
  myRole: "owner" | "commissioner" | "member" | null;
};

type LeagueSeasonSummary = {
  id: number;
  name: string;
  status:
    | "Signup"
    | "Drafting"
    | "Active"
    | "Playoffs"
    | "Completed"
    | "Archived"
    | string;
  formatType:
    | "RoundRobin"
    | "Swiss"
    | "SingleElim"
    | "DoubleElim"
    | "GroupsPlayoffs"
    | "Hybrid"
    | string;
  startsAt: string | null;
  endsAt: string | null;
};

type LeagueMember = {
  userId: number;
  username: string;
  displayName: string | null;
  role: "owner" | "commissioner" | "member" | string;
  joinedAt: string;
};

type UpdateLeagueBody = {
  name?: string;
  description?: string | null;
  logoUrl?: string | null;
  visibility?: LeagueVisibility;
  password?: string | null;
};

type HttpErrorWithStatus = Error & { status?: number };

type LeagueTab = "overview" | "seasons" | "members" | "settings";

async function fetchJson<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    credentials: "include",
    cache: "no-store",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
  });

  let json: any = null;
  try {
    json = await res.json();
  } catch {
    // 204 etc.
  }

  if (!res.ok) {
    const message =
      json?.message || json?.error || `Request failed (${res.status})`;
    const err = new Error(message) as HttpErrorWithStatus;
    err.status = res.status;
    throw err;
  }

  return json as T;
}

function formatDate(input?: string | null): string {
  if (!input) return "—";
  const d = new Date(input);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
  });
}

function mapLeagueDetail(raw: any): LeagueDetail {
  return {
    id: raw.id,
    name: raw.name ?? "Unnamed league",
    description: raw.description ?? null,
    logoUrl: raw.logoUrl ?? raw.logo_url ?? null,
    visibility: raw.visibility ?? "public",
    ownerUserId: raw.ownerUserId ?? raw.owner_user_id,
    ownerUsername: raw.ownerUsername ?? raw.owner_username ?? null,
    memberCount: raw.memberCount ?? raw.member_count ?? 0,
    activeSeasonCount: raw.activeSeasonCount ?? raw.active_season_count ?? 0,
    createdAt: raw.createdAt ?? raw.created_at ?? new Date().toISOString(),
    isMember: !!raw.isMember,
    myRole: raw.myRole ?? raw.my_role ?? null,
  };
}

function mapSeasons(raw: any): LeagueSeasonSummary[] {
  const items = Array.isArray(raw?.items)
    ? raw.items
    : Array.isArray(raw)
    ? raw
    : [];
  return items.map((s: any) => ({
    id: s.id,
    name: s.name ?? "Unnamed season",
    status: s.status ?? "Unknown",
    formatType: s.formatType ?? s.format_type ?? "RoundRobin",
    startsAt: s.startsAt ?? s.starts_at ?? null,
    endsAt: s.endsAt ?? s.ends_at ?? null,
  }));
}

function mapMembers(raw: any): LeagueMember[] {
  const items = Array.isArray(raw?.items)
    ? raw.items
    : Array.isArray(raw)
    ? raw
    : [];
  return items.map((m: any) => ({
    userId: m.userId ?? m.user_id,
    username: m.username ?? "unknown",
    displayName: m.displayName ?? m.display_name ?? null,
    role: m.role ?? "member",
    joinedAt: m.joinedAt ?? m.joined_at ?? "",
  }));
}

export default function LeagueHubPage() {
  const { leagueId } = useParams();
  const router = useRouter();
  const id = Number(leagueId);

  const [tab, setTab] = useState<LeagueTab>("overview");

  const [league, setLeague] = useState<LeagueDetail | null>(null);
  const [members, setMembers] = useState<LeagueMember[]>([]);
  const [seasons, setSeasons] = useState<LeagueSeasonSummary[]>([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);

  // settings form
  const [settingsName, setSettingsName] = useState("");
  const [settingsDescription, setSettingsDescription] = useState("");
  const [settingsVisibility, setSettingsVisibility] =
    useState<LeagueVisibility>("public");
  const [settingsSaving, setSettingsSaving] = useState(false);

  // member actions
  const [memberActionUserId, setMemberActionUserId] = useState<number | null>(
    null
  );

  const myRole = league?.myRole ?? null;
  const canManage = myRole === "owner" || myRole === "commissioner";
  const canDelete = myRole === "owner";
  const canLeave = myRole !== "owner";

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError(null);
      setActionError(null);
      setInfoMessage(null);

      try {
        const [rawLeague, rawMembers, rawSeasons] = await Promise.all([
          fetchJson<any>(`/leagues/${id}`),
          fetchJson<any>(`/leagues/${id}/members`),
          fetchJson<any>(`/leagues/${id}/seasons`),
        ]);

        if (cancelled) return;

        const l = mapLeagueDetail(rawLeague);
        setLeague(l);
        setMembers(mapMembers(rawMembers));
        setSeasons(mapSeasons(rawSeasons));

        setSettingsName(l.name);
        setSettingsDescription(l.description ?? "");
        setSettingsVisibility(l.visibility);
      } catch (e: any) {
        if (cancelled) return;
        setError(e.message ?? "Failed to load league hub.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    if (Number.isFinite(id) && id > 0) load();
    else {
      setError("Invalid league id.");
      setLoading(false);
    }

    return () => {
      cancelled = true;
    };
  }, [id]);

  async function refreshSeasons() {
    const raw = await fetchJson<any>(`/leagues/${id}/seasons`);
    setSeasons(mapSeasons(raw));
  }

  async function createSeason() {
    if (!canManage) return;

    setActionError(null);
    setInfoMessage(null);

    const name = window.prompt("Season name?");
    if (!name) return;

    try {
      // This endpoint does NOT exist in your backend yet.
      // We still wire the button so the UI is ready.
      await fetchJson(`/leagues/${id}/seasons`, {
        method: "POST",
        body: JSON.stringify({ name }),
      });

      await refreshSeasons();
      setInfoMessage("Season created.");
    } catch (err: any) {
      const status = err?.status as number | undefined;

      if (status === 404) {
        setActionError(
          "Season creation isn’t implemented on the API yet (POST /leagues/:leagueId/seasons is missing)."
        );
        return;
      }

      setActionError(err?.message ?? "Failed to create season.");
    }
  }

  async function leaveLeague() {
    if (!league || !canLeave) return;
    if (!confirm("Leave this league?")) return;

    setActionError(null);
    try {
      await fetchJson(`/leagues/${id}/leave`, { method: "POST" });
      router.push("/leagues");
    } catch (err: any) {
      setActionError(err?.message ?? "Failed to leave league.");
    }
  }

  async function deleteLeague() {
    if (!league || !canDelete) return;
    if (!confirm("DELETE THIS LEAGUE? This cannot be undone.")) return;

    setActionError(null);
    try {
      await fetchJson(`/leagues/${id}`, { method: "DELETE" });
      router.push("/leagues");
    } catch (err: any) {
      setActionError(err?.message ?? "Failed to delete league.");
    }
  }

  async function promoteMember(member: LeagueMember) {
    if (!league || !canManage) return;
    setMemberActionUserId(member.userId);
    setActionError(null);

    try {
      const res = await fetchJson<any>(
        `/leagues/${id}/members/${member.userId}/promote`,
        { method: "POST", body: JSON.stringify({}) }
      );
      setMembers(mapMembers(res));
    } catch (err: any) {
      setActionError(err?.message ?? "Failed to promote member.");
    } finally {
      setMemberActionUserId(null);
    }
  }

  async function demoteMember(member: LeagueMember) {
    if (!league || !canManage) return;
    setMemberActionUserId(member.userId);
    setActionError(null);

    try {
      const res = await fetchJson<any>(
        `/leagues/${id}/members/${member.userId}/demote`,
        { method: "POST", body: JSON.stringify({}) }
      );
      setMembers(mapMembers(res));
    } catch (err: any) {
      setActionError(err?.message ?? "Failed to demote member.");
    } finally {
      setMemberActionUserId(null);
    }
  }

  async function kickMember(member: LeagueMember) {
    if (!league || !canManage) return;
    if (!confirm(`Kick ${member.displayName ?? member.username}?`)) return;

    setMemberActionUserId(member.userId);
    setActionError(null);

    try {
      const res = await fetchJson<any>(
        `/leagues/${id}/members/${member.userId}`,
        { method: "DELETE" }
      );
      setMembers(mapMembers(res));
    } catch (err: any) {
      setActionError(err?.message ?? "Failed to remove member.");
    } finally {
      setMemberActionUserId(null);
    }
  }

  async function saveSettings(e: FormEvent) {
    e.preventDefault();
    if (!league || !canManage) return;

    setSettingsSaving(true);
    setActionError(null);
    setInfoMessage(null);

    const body: UpdateLeagueBody = {
      name: settingsName.trim() || league.name,
      description: settingsDescription.trim() || null,
      visibility: settingsVisibility,
    };

    try {
      const updated = await fetchJson<any>(`/leagues/${id}`, {
        method: "PATCH",
        body: JSON.stringify(body),
      });
      const mapped = mapLeagueDetail(updated);
      setLeague(mapped);
      setInfoMessage("Saved.");
    } catch (err: any) {
      setActionError(err?.message ?? "Failed to save league settings.");
    } finally {
      setSettingsSaving(false);
    }
  }

  if (error) {
    return (
      <main className="app-shell">
        <div className="form-error">{error}</div>
      </main>
    );
  }

  if (loading || !league) {
    return (
      <main className="app-shell">
        <div className="card">
          <div className="card-body">Loading league…</div>
        </div>
      </main>
    );
  }

  const ownerLabel = league.ownerUsername
    ? league.ownerUsername
    : `User #${league.ownerUserId}`;

  return (
    <main className="league-hub-page">
      <header className="page-header">
        <div>
          <p className="breadcrumb">
            <Link href="/leagues" className="link">
              Leagues
            </Link>{" "}
            / <span className="breadcrumb-current">{league.name}</span>
          </p>
          <h1 className="page-title">{league.name}</h1>
          {league.description && (
            <p className="page-subtitle">{league.description}</p>
          )}
        </div>

        <div className="page-header-actions">
          <Link href="/dashboard" className="btn btn-sm btn-ghost">
            Back to dashboard
          </Link>
        </div>
      </header>

      {actionError && <div className="form-error">{actionError}</div>}
      {infoMessage && <div className="form-success">{infoMessage}</div>}

      <section className="league-meta card mt-md">
        <div className="card-body league-meta-body">
          <div className="league-meta-left">
            <div className="league-avatar">
              <span className="league-avatar-initials">
                {league.name.slice(0, 2).toUpperCase()}
              </span>
            </div>

            <div className="stack stack-xs">
              <div className="stack stack-xs">
                <span className="pill pill-outline pill-xs">
                  {league.visibility}
                </span>
                <span className="text-muted text-xs">Owner: {ownerLabel}</span>
              </div>

              <div className="text-muted text-xs">
                {league.memberCount} member{league.memberCount === 1 ? "" : "s"}
              </div>

              <div className="pill pill-soft pill-xs">
                Your role: {league.myRole ?? "—"}
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="tabs tabs--underline mt-md">
        <button
          type="button"
          className={
            "tabs-item" + (tab === "overview" ? " tabs-item--active" : "")
          }
          onClick={() => setTab("overview")}
        >
          Overview
        </button>

        <button
          type="button"
          className={
            "tabs-item" + (tab === "seasons" ? " tabs-item--active" : "")
          }
          onClick={() => setTab("seasons")}
        >
          Seasons
        </button>

        <button
          type="button"
          className={
            "tabs-item" + (tab === "members" ? " tabs-item--active" : "")
          }
          onClick={() => setTab("members")}
        >
          Members
        </button>

        {canManage && (
          <button
            type="button"
            className={
              "tabs-item" + (tab === "settings" ? " tabs-item--active" : "")
            }
            onClick={() => setTab("settings")}
          >
            Settings
          </button>
        )}
      </div>

      <section className="league-tab-content mt-md">
        {tab === "overview" && (
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">League overview</h2>
              <p className="card-subtitle">Basic info and current activity.</p>
            </div>
            <div className="card-body">
              <div className="text-muted text-xs">
                Created: {formatDate(league.createdAt)}
              </div>
              <div className="text-muted text-xs">
                Active seasons: {league.activeSeasonCount}
              </div>
              <div className="text-muted text-xs">
                Your role: {league.myRole ?? "—"}
              </div>
            </div>
          </div>
        )}

        {tab === "seasons" && (
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Seasons</h2>
              <p className="card-subtitle">Seasons in this league.</p>
            </div>

            <div className="card-body">
              {canManage && (
                <button
                  type="button"
                  className="btn btn-sm btn-primary"
                  onClick={createSeason}
                >
                  Create season
                </button>
              )}

              {seasons.length === 0 ? (
                <div className="empty-state">No seasons yet.</div>
              ) : (
                <div className="table-wrapper">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Format</th>
                        <th>Dates</th>
                      </tr>
                    </thead>
                    <tbody>
                      {seasons.map((s) => (
                        <tr key={s.id}>
                          <td>{s.name}</td>
                          <td>
                            <span className="badge badge-soft">{s.status}</span>
                          </td>
                          <td className="text-muted">{s.formatType}</td>
                          <td className="text-muted">
                            {formatDate(s.startsAt)} – {formatDate(s.endsAt)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === "members" && (
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Members</h2>
              <p className="card-subtitle">
                Everyone currently in this league.
              </p>
            </div>

            <div className="card-body">
              <ul className="list list-divided">
                {members.map((m) => {
                  const isOwner = m.userId === league.ownerUserId;
                  const display = m.displayName ?? m.username;

                  return (
                    <li key={m.userId} className="list-item">
                      <div className="list-item-main">
                        <div className="list-item-title-row">
                          <div className="pill pill-soft">{display}</div>
                          <span className="pill pill-outline pill-xs">
                            {isOwner ? "owner" : m.role}
                          </span>
                        </div>
                        <div className="text-muted text-xs">
                          Joined: {formatDate(m.joinedAt)}
                        </div>
                      </div>

                      <div className="list-item-actions">
                        {canManage && !isOwner && (
                          <>
                            {m.role === "member" ? (
                              <button
                                type="button"
                                className="btn btn-xs btn-secondary"
                                onClick={() => promoteMember(m)}
                                disabled={memberActionUserId === m.userId}
                              >
                                {memberActionUserId === m.userId
                                  ? "Working…"
                                  : "Promote"}
                              </button>
                            ) : (
                              <button
                                type="button"
                                className="btn btn-xs btn-secondary"
                                onClick={() => demoteMember(m)}
                                disabled={memberActionUserId === m.userId}
                              >
                                {memberActionUserId === m.userId
                                  ? "Working…"
                                  : "Demote"}
                              </button>
                            )}

                            <button
                              type="button"
                              className="btn btn-xs btn-danger"
                              onClick={() => kickMember(m)}
                              disabled={memberActionUserId === m.userId}
                            >
                              {memberActionUserId === m.userId
                                ? "Working…"
                                : "Kick"}
                            </button>
                          </>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        )}

        {tab === "settings" && canManage && (
          <div className="stack stack-lg">
            <section className="card">
              <div className="card-header">
                <h2 className="card-title">League settings</h2>
                <p className="card-subtitle">
                  Edit league identity and visibility.
                </p>
              </div>

              <div className="card-body">
                <form className="form" onSubmit={saveSettings}>
                  <div className="form-row">
                    <label className="label">League name</label>
                    <input
                      className="input"
                      value={settingsName}
                      onChange={(e) => setSettingsName(e.target.value)}
                    />
                  </div>

                  <div className="form-row">
                    <label className="label">Description</label>
                    <textarea
                      className="input"
                      rows={4}
                      value={settingsDescription}
                      onChange={(e) => setSettingsDescription(e.target.value)}
                    />
                  </div>

                  <div className="form-row">
                    <label className="label">Visibility</label>
                    <select
                      className="input"
                      value={settingsVisibility}
                      onChange={(e) => setSettingsVisibility(e.target.value)}
                    >
                      <option value="public">public</option>
                      <option value="private">private</option>
                      <option value="password-protected">
                        password-protected
                      </option>
                      <option value="invite-only">invite-only</option>
                    </select>
                  </div>

                  <div className="form-actions">
                    <button
                      className="btn btn-sm btn-primary"
                      type="submit"
                      disabled={settingsSaving}
                    >
                      {settingsSaving ? "Saving…" : "Save changes"}
                    </button>
                  </div>
                </form>
              </div>
            </section>

            <section className="card card--danger">
              <div className="card-header">
                <h2 className="card-title">Danger zone</h2>
                <p className="card-subtitle">These actions are irreversible.</p>
              </div>

              <div className="card-body">
                <div className="stack stack-sm">
                  {canLeave && (
                    <div className="danger-row">
                      <div>
                        <div className="text-strong">Leave league</div>
                        <div className="text-muted text-xs">
                          Removes you from this league.
                        </div>
                      </div>
                      <button
                        type="button"
                        className="btn btn-sm btn-secondary"
                        onClick={leaveLeague}
                      >
                        Leave
                      </button>
                    </div>
                  )}

                  {canDelete && (
                    <div className="danger-row">
                      <div>
                        <div className="text-strong">Delete league</div>
                        <div className="text-muted text-xs">
                          Permanently deletes this league and everything under
                          it.
                        </div>
                      </div>
                      <button
                        type="button"
                        className="btn btn-sm btn-danger"
                        onClick={deleteLeague}
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </section>
          </div>
        )}
      </section>
    </main>
  );
}
