// apps/web/middleware.ts
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

const PUBLIC_PATHS = new Set<string>([
  "/login",
  "/register",
  "/forgot-password"
  // You can add "/" here if you want the home page to be public.
]);

export function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;

  // Allow _next, static, etc. (assets)
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/static") ||
    pathname === "/favicon.ico"
  ) {
    return NextResponse.next();
  }

  // Public auth pages are always allowed
  if (PUBLIC_PATHS.has(pathname)) {
    return NextResponse.next();
  }

  // Look for the backend session cookie.
  // Fastify sets "sid" when you log in.
  const sidCookie = req.cookies.get("sid");

  // If no session cookie: redirect to /login, with ?next=originalPath
  if (!sidCookie?.value) {
    const loginUrl = req.nextUrl.clone();
    loginUrl.pathname = "/login";
    loginUrl.searchParams.set("next", pathname + search);
    return NextResponse.redirect(loginUrl);
  }

  // Otherwise, let the request through.
  return NextResponse.next();
}

// Apply middleware to all application routes.
export const config = {
  matcher: ["/((?!api|_next|static|favicon.ico).*)"]
};
